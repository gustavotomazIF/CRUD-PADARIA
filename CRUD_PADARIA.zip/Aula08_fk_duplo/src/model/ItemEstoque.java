package model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class ItemEstoque implements Serializable { 

    @Id
    @GeneratedValue
    private int id;
    private Date dataValidade; 
    private String lote; 
    
    // --- NOVO CAMPO ADICIONADO ---
    private int quantidade;
    
    @ManyToOne 
    private Produto produto; 
    
    @ManyToOne
    private Fornecedor fornecedor; 

    public ItemEstoque() {
    }

    // Construtor atualizado
    public ItemEstoque(int id, Date dataValidade, String lote, int quantidade, Produto produto, Fornecedor fornecedor) {
        this.id = id;
        this.dataValidade = dataValidade;
        this.lote = lote;
        this.quantidade = quantidade; // Adicionado
        this.produto = produto;
        this.fornecedor = fornecedor;
    }

    // --- GETTERS E SETTERS ---
    // (id, dataValidade, lote, produto, fornecedor getters/setters...)

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDataValidade() {
        return dataValidade;
    }

    public void setDataValidade(Date dataValidade) {
        this.dataValidade = dataValidade;
    }

    public String getLote() {
        return lote;
    }

    public void setLote(String lote) {
        this.lote = lote;
    }
    
    // --- GETTER E SETTER PARA O NOVO CAMPO ---
    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
    // --- FIM DA ADIÇÃO ---

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public Fornecedor getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(Fornecedor fornecedor) {
        this.fornecedor = fornecedor;
    }
}