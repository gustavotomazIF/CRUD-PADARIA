package model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Produto implements Serializable { // Renomeado de Cliente

    @Id
    @GeneratedValue
    private int id;
    private String nome;
    private float preco; // Alterado de String cpf
    
    // Um Produto pode estar em vários Itens de Estoque
    @OneToMany(mappedBy = "produto", fetch = FetchType.LAZY) // 'mappedBy' alterado de "cliente"
    private List<ItemEstoque> itensEstoque; // Alterado de List<Reserva> reservas

    public Produto() {
    }

    public Produto(int id, String nome, float preco) { // Construtor adaptado
        this.id = id;
        this.nome = nome;
        this.preco = preco;
    }

    // Getters e Setters adaptados
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public List<ItemEstoque> getItensEstoque() {
        return itensEstoque;
    }

    public void setItensEstoque(List<ItemEstoque> itensEstoque) {
        this.itensEstoque = itensEstoque;
    }
}