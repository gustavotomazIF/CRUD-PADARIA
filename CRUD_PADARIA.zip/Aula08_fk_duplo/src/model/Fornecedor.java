package model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Fornecedor implements Serializable { 

    @Id
    @GeneratedValue
    private int id;
    private String nome; 
    private String cnpj; 
    
    // --- NOVO CAMPO ADICIONADO ---
    private String telefone;
    
    @OneToMany(mappedBy = "fornecedor", fetch = FetchType.LAZY) 
    private List<ItemEstoque> itensEstoque; 

    public Fornecedor() {
    }

    // Construtor atualizado
    public Fornecedor(int id, String nome, String cnpj, String telefone) { 
        this.id = id;
        this.nome = nome;
        this.cnpj = cnpj;
        this.telefone = telefone; // Adicionado
    }

    // --- GETTERS E SETTERS ---
    // (id, nome, cnpj getters/setters...)
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }
    
    // --- GETTER E SETTER PARA O NOVO CAMPO ---
    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    // --- FIM DA ADIÇÃO ---

    public List<ItemEstoque> getItensEstoque() {
        return itensEstoque;
    }

    public void setItensEstoque(List<ItemEstoque> itensEstoque) {
        this.itensEstoque = itensEstoque;
    }
}