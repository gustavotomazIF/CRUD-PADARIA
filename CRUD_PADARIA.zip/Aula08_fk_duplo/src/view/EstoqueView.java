package view;

// (Imports permanecem os mesmos, mas adicione 'util.Data' se não estiver lá)
import controller.ProdutoController;
import controller.FornecedorController;
import controller.EstoqueController;
import java.awt.event.ItemEvent;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import model.Produto;
import model.Fornecedor;
import model.ItemEstoque;
import util.Data; // (Assumindo que você tem a classe 'util.Data' do projeto original)
import java.awt.Color;
import java.awt.Component;
import java.util.Date;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class EstoqueView extends javax.swing.JFrame {

    // (Variáveis de classe permanecem as mesmas)
    Produto produto = null; 
    Fornecedor fornecedor = null; 
    ItemEstoque itemEstoque = new ItemEstoque();
    List<Produto> produtos;
    List<Fornecedor> fornecedores;
    List<ItemEstoque> itensEstoque;

    public EstoqueView() {
        initComponents();
        loadComboProdutos();
        loadComboFornecedores();
        loadTabela();
    }

    // --- CÓDIGO DO DESIGN (initComponents) ATUALIZADO ---
    // (Eu adicionei 'jLabel5' e 'txtQuantidade')
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        cmbProdutos = new javax.swing.JComboBox<>();
        Produto = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblEstoque = new javax.swing.JTable();
        btnSalvarEstoque = new javax.swing.JButton();
        btnProduto = new javax.swing.JButton();
        btnNovo = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        cmbFornecedores = new javax.swing.JComboBox<>();
        btnFornecedor = new javax.swing.JButton();
        txtValidade = new javax.swing.JFormattedTextField();
        jLabel1 = new javax.swing.JLabel();
        Produto1 = new javax.swing.JLabel();
        Produto2 = new javax.swing.JLabel();
        Produto3 = new javax.swing.JLabel();
        txtLote = new javax.swing.JTextField();
        Produto4 = new javax.swing.JLabel();
        txtQuantidade = new javax.swing.JTextField();
        VerTudo = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Estoque Padaria");
        setResizable(false);
        addWindowFocusListener(new java.awt.event.WindowFocusListener() {
            public void windowGainedFocus(java.awt.event.WindowEvent evt) {
                formWindowGainedFocus(evt);
            }
            public void windowLostFocus(java.awt.event.WindowEvent evt) {
            }
        });

        cmbProdutos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbProdutos.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cmbProdutosItemStateChanged(evt);
            }
        });

        Produto.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Produto.setText("Produto");

        tblEstoque.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblEstoque.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tblEstoque.setEditingColumn(0);
        tblEstoque.setEditingRow(0);
        tblEstoque.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblEstoqueMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblEstoque);

        btnSalvarEstoque.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Check_16x16.png"))); // NOI18N
        btnSalvarEstoque.setText("Salvar no Estoque");
        btnSalvarEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarEstoqueActionPerformed(evt);
            }
        });

        btnProduto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Add_16x16.png"))); // NOI18N
        btnProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProdutoActionPerformed(evt);
            }
        });

        btnNovo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/New_16x16.png"))); // NOI18N
        btnNovo.setText("Novo");
        btnNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNovoActionPerformed(evt);
            }
        });

        btnExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Cancel_16x16.png"))); // NOI18N
        btnExcluir.setText("Excluir");
        btnExcluir.setEnabled(false);
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        cmbFornecedores.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbFornecedores.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cmbFornecedoresItemStateChanged(evt);
            }
        });

        btnFornecedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Add_16x16.png"))); // NOI18N
        btnFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFornecedorActionPerformed(evt);
            }
        });

        try {
            txtValidade.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtValidade.setFont(new java.awt.Font("Segoe UI Semibold", 2, 18)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/product.png"))); // NOI18N
        jLabel1.setText("Estoque da Padaria");

        Produto1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Produto1.setText("Validade");

        Produto2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Produto2.setText("Fornecedor");

        Produto3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Produto3.setText("Lote");

        Produto4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Produto4.setText("Quantidade");

        VerTudo.setText("Ver Tabela Completa");
        VerTudo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VerTudoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(110, 110, 110)
                .addComponent(Produto, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Produto2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(129, 129, 129))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(cmbProdutos, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cmbFornecedores, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnSalvarEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(53, 53, 53))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(137, 137, 137)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnNovo, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(110, 110, 110)
                                        .addComponent(Produto1))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(94, 94, 94)
                                        .addComponent(txtValidade, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(110, 110, 110)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(txtQuantidade))
                                    .addComponent(Produto4))))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(94, 94, 94)
                                .addComponent(txtLote, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(180, 180, 180)
                                .addComponent(Produto3))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(33, 33, 33)
                                .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(117, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(VerTudo)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(122, 122, 122)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Produto, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Produto2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbProdutos, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbFornecedores, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Produto3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Produto1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Produto4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtValidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtLote, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalvarEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNovo, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(VerTudo)
                .addGap(3, 3, 3)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
                .addGap(18, 18, 18))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void tblEstoqueMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblEstoqueMouseClicked
        loadItemEstoque();
    }//GEN-LAST:event_tblEstoqueMouseClicked

    private void btnSalvarEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarEstoqueActionPerformed
        salvar();
    }//GEN-LAST:event_btnSalvarEstoqueActionPerformed

    private void cmbProdutosItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cmbProdutosItemStateChanged
        eventoComboProdutos(evt);
    }//GEN-LAST:event_cmbProdutosItemStateChanged

    private void btnProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProdutoActionPerformed
        addProduto();
    }//GEN-LAST:event_btnProdutoActionPerformed

    private void btnNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNovoActionPerformed
        limpar();
    }//GEN-LAST:event_btnNovoActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        excluir();
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void formWindowGainedFocus(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowGainedFocus
        loadComboProdutos();
        loadComboFornecedores();
    }//GEN-LAST:event_formWindowGainedFocus

    private void cmbFornecedoresItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cmbFornecedoresItemStateChanged
        eventoComboFornecedores(evt);
    }//GEN-LAST:event_cmbFornecedoresItemStateChanged

    private void btnFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFornecedorActionPerformed
        addFornecedor();
    }//GEN-LAST:event_btnFornecedorActionPerformed

    private void VerTudoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VerTudoActionPerformed
        new EstoqueCompletoView().setVisible(true);
    }//GEN-LAST:event_VerTudoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
//        try {
//            javax.swing.UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
////            javax.swing.UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
////            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
////                System.out.println(info);
////                if ("Metal".equals(info.getName())) {
////                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
////                    break;
////                }
////            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(ReservaView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(ReservaView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(ReservaView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(ReservaView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EstoqueView().setVisible(true);

            }

        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Produto;
    private javax.swing.JLabel Produto1;
    private javax.swing.JLabel Produto2;
    private javax.swing.JLabel Produto3;
    private javax.swing.JLabel Produto4;
    private javax.swing.JButton VerTudo;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnFornecedor;
    private javax.swing.JButton btnNovo;
    private javax.swing.JButton btnProduto;
    private javax.swing.JButton btnSalvarEstoque;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JComboBox<String> cmbFornecedores;
    private javax.swing.JComboBox<String> cmbProdutos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblEstoque;
    private javax.swing.JTextField txtLote;
    private javax.swing.JTextField txtQuantidade;
    private javax.swing.JFormattedTextField txtValidade;
    // End of variables declaration//GEN-END:variables

  private void loadComboProdutos() {
        cmbProdutos.removeAllItems(); 
        cmbProdutos.addItem("");
        produtos = new ProdutoController().listar();
        if (!produtos.isEmpty()) { 
            for (Produto p : produtos) { 
                cmbProdutos.addItem(p.getNome()); 
            }
        }
    }
    private void loadComboFornecedores() {
        cmbFornecedores.removeAllItems(); 
        cmbFornecedores.addItem("");
        fornecedores = new FornecedorController().listar();
        if (!fornecedores.isEmpty()) { 
            for (Fornecedor f : fornecedores) { 
                cmbFornecedores.addItem(f.getNome()); 
            }
        }
    }

   private void loadTabela() {
        List<ItemEstoque> todos = new EstoqueController().listar();
        
        // 2. Lógica para pegar apenas os ÚLTIMOS 5
        int total = todos.size();
        int inicio = Math.max(0, total - 5); // Garante que não dê erro se tiver menos de 5
        
        // A 'itensEstoque' (que a tabela usa) será apenas uma sub-lista
        itensEstoque = todos.subList(inicio, total);

        // O resto continua IGUAL
        String[] colunas = new String[]{"Produto", "Qtd", "Validade", "Fornecedor", "Lote"};
        String[][] linhas = new String[itensEstoque.size()][colunas.length];

        for (int i = 0; i < itensEstoque.size(); i++) {
            linhas[i][0] = itensEstoque.get(i).getProduto().getNome();
            linhas[i][1] = String.valueOf(itensEstoque.get(i).getQuantidade());
            linhas[i][2] = Data.dateNoTimeToString(itensEstoque.get(i).getDataValidade());
            linhas[i][3] = itensEstoque.get(i).getFornecedor().getNome();
            linhas[i][4] = itensEstoque.get(i).getLote();
        }

        DefaultTableModel modelo = new DefaultTableModel(linhas, colunas);
        tblEstoque.setModel(modelo); 
        tblEstoque.setDefaultEditor(Object.class, null);

    // --- CÓDIGO NOVO: PINTAR VENCIDOS DE VERMELHO ---
    
    tblEstoque.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            // 1. Chama o comportamento padrão (cores de seleção, fundo, etc.)
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

            // 2. Pega o item correspondente na lista da memória
            // (O índice da linha visual 'row' é o mesmo da lista 'itensEstoque')
            if (row < itensEstoque.size()) { // Proteção contra erros de índice
                ItemEstoque item = itensEstoque.get(row);

                // 3. Verifica a data (Se validade for ANTES de agora)
                if (item.getDataValidade() != null && item.getDataValidade().before(new Date())) {
                    setForeground(Color.RED); // Muda a cor da letra para Vermelho
                    // setBackground(Color.YELLOW); // (Opcional) Se quiser mudar o fundo
                } else {
                    // Se não estiver vencido, restaura a cor padrão
                    // (Preto se normal, Branco se estiver selecionado)
                    if (isSelected) {
                        setForeground(table.getSelectionForeground());
                    } else {
                        setForeground(Color.BLACK);
                    }
                }
            }
            return this;
        }
    });
    }

    private void loadItemEstoque() {
        itemEstoque = itensEstoque.get(tblEstoque.getSelectedRow());

        txtValidade.setText(util.Data.dateToString(itemEstoque.getDataValidade())); 
        txtLote.setText(itemEstoque.getLote());
        txtQuantidade.setText(String.valueOf(itemEstoque.getQuantidade())); // Adicionado

        // (Lógica dos combos não muda)
        int iProduto = 1;
        for (Produto p : produtos) {
            if (p.getId() == itemEstoque.getProduto().getId()) {
                cmbProdutos.setSelectedIndex(iProduto);
            }
            iProduto++;
        }
        int iFornecedor = 1;
        for (Fornecedor f : fornecedores) {
            if (f.getId() == itemEstoque.getFornecedor().getId()) {
                cmbFornecedores.setSelectedIndex(iFornecedor);
            }
            iFornecedor++;
        }

        btnExcluir.setEnabled(true);
    }

    private void salvar() {        
        if (produto == null || fornecedor == null) {
            return; 
        }
        
        try {
            itemEstoque.setDataValidade(util.Data.stringToDateNoTime(txtValidade.getText())); 
            itemEstoque.setProduto(produto); 
            itemEstoque.setFornecedor(fornecedor); 
            itemEstoque.setLote(txtLote.getText());
            itemEstoque.setQuantidade(Integer.parseInt(txtQuantidade.getText())); // Adicionado
            
            new EstoqueController().salvar(itemEstoque); 
            loadTabela(); 
            limpar(); 
        } catch (NumberFormatException e) {
             javax.swing.JOptionPane.showMessageDialog(this, "O campo 'Quantidade' deve ser um número inteiro.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void limpar() {
        produto = null;
        fornecedor = null;
        itemEstoque = new ItemEstoque();
        cmbProdutos.setSelectedIndex(0);
        cmbFornecedores.setSelectedIndex(0);
        txtValidade.setText("");
        txtLote.setText("");
        txtQuantidade.setText(""); // Adicionado
        loadTabela();
        btnExcluir.setEnabled(false);
    }

    // (eventoComboProdutos e eventoComboFornecedores não mudam)
    private void eventoComboProdutos(ItemEvent evt) {
        if (evt.getStateChange() == ItemEvent.SELECTED && cmbProdutos.getSelectedIndex() > 0) {
            produto = produtos.get(cmbProdutos.getSelectedIndex() - 1);
        } else {
            produto = null;
        }
    }
    private void eventoComboFornecedores(ItemEvent evt) {
        if (evt.getStateChange() == ItemEvent.SELECTED && cmbFornecedores.getSelectedIndex() > 0) {
            fornecedor = fornecedores.get(cmbFornecedores.getSelectedIndex() - 1);
        } else {
            fornecedor = null;
        }
    }
    

    // (addProduto e addFornecedor não mudam)
    private void addProduto() {
        new ProdutoView().setVisible(true);
    }
    private void addFornecedor() {
        new FornecedorView().setVisible(true);
    }

    // (excluir não muda)
    private void excluir() {
        new EstoqueController().excluir(itemEstoque); 
        itensEstoque.remove(itemEstoque); 
        loadTabela(); 
        limpar(); 
    }
}