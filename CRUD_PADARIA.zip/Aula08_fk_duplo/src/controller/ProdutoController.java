package controller;

import java.util.List;
import model.Produto; // Importado Produto

public class ProdutoController extends Controller<Produto> { // Renomeado

    @Override
    public boolean salvar(Produto t) { // Tipo Produto
        return super.salvar(t);
    }

    @Override
    public boolean excluir(Produto t) { // Tipo Produto
        return super.excluir(t);
    }

    public List<Produto> buscar(String campo, String valor) { // Tipo Produto
        return super.listar(Produto.class, campo, valor);
    }

    public Produto get(int id) { // Tipo Produto
        return super.get(Produto.class, id);
    }

    public List<Produto> listar() { // Tipo Produto
        return super.listar(Produto.class, "nome", "");
    }
}