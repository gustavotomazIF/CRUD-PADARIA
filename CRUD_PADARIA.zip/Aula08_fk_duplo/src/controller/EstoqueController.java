package controller;

import java.util.List;
import model.ItemEstoque; // Importado ItemEstoque

public class EstoqueController extends Controller<ItemEstoque> { // Renomeado

    @Override
    public boolean salvar(ItemEstoque t) { // Tipo ItemEstoque
        return super.salvar(t);
    }

    @Override
    public boolean excluir(ItemEstoque t) { // Tipo ItemEstoque
        return super.excluir(t);
    }

    public List<ItemEstoque> buscar(String campo, String valor) { // Tipo ItemEstoque
        return super.listar(ItemEstoque.class, campo, valor);
    }

    public ItemEstoque get(int id) { // Tipo ItemEstoque
        return super.get(ItemEstoque.class, id);
    }

    public List<ItemEstoque> listar() { // Tipo ItemEstoque
        return super.listar(ItemEstoque.class, "lote", ""); // Adaptado
    }
}