package controller;

import java.util.List;
import model.Fornecedor; // Importado Fornecedor

public class FornecedorController extends Controller<Fornecedor> { // Renomeado

    @Override
    public boolean salvar(Fornecedor t) { // Tipo Fornecedor
        return super.salvar(t);
    }

    @Override
    public boolean excluir(Fornecedor t) { // Tipo Fornecedor
        return super.excluir(t);
    }

    public List<Fornecedor> buscar(String campo, String valor) { // Tipo Fornecedor
        return super.listar(Fornecedor.class, campo, valor);
    }

    public Fornecedor get(int id) { // Tipo Fornecedor
        return super.get(Fornecedor.class, id);
    }

    public List<Fornecedor> listar() { // Tipo Fornecedor
        return super.listar(Fornecedor.class, "nome", "");
    }
}