package model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Fornecedor implements Serializable { // Renomeado de Quarto

    @Id
    @GeneratedValue
    private int id;
    private String nome; // Pode ser a Razão Social ou Nome Fantasia
    private String cnpj; // Alterado de float preco
    
    // Um Fornecedor pode estar em vários Itens de Estoque
    @OneToMany(mappedBy = "fornecedor", fetch = FetchType.LAZY) // 'mappedBy' alterado de "quarto"
    private List<ItemEstoque> itensEstoque; // Alterado de List<Reserva> reservas

    public Fornecedor() {
    }

    public Fornecedor(int id, String nome, String cnpj) { // Construtor adaptado
        this.id = id;
        this.nome = nome;
        this.cnpj = cnpj;
    }

    // Getters e Setters adaptados
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public List<ItemEstoque> getItensEstoque() {
        return itensEstoque;
    }

    public void setItensEstoque(List<ItemEstoque> itensEstoque) {
        this.itensEstoque = itensEstoque;
    }
}