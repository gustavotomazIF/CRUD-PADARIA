package model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class ItemEstoque implements Serializable { // Renomeado de Reserva

    @Id
    @GeneratedValue
    private int id;
    private Date dataValidade; // Alterado de dataReserva
    private String lote; // Alterado de observacao
    
    // Relação N-para-1 com Produto
    @ManyToOne 
    private Produto produto; // Alterado de Cliente cliente
    
    // Relação N-para-1 com Fornecedor
    @ManyToOne
    private Fornecedor fornecedor; // Alterado de Quarto quarto

    public ItemEstoque() {
    }

    // Construtor adaptado
    public ItemEstoque(int id, Date dataValidade, String lote, Produto produto, Fornecedor fornecedor) {
        this.id = id;
        this.dataValidade = dataValidade;
        this.lote = lote;
        this.produto = produto;
        this.fornecedor = fornecedor;
    }

    // Getters e Setters adaptados
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDataValidade() {
        return dataValidade;
    }

    public void setDataValidade(Date dataValidade) {
        this.dataValidade = dataValidade;
    }

    public String getLote() {
        return lote;
    }

    public void setLote(String lote) {
        this.lote = lote;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public Fornecedor getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(Fornecedor fornecedor) {
        this.fornecedor = fornecedor;
    }
}